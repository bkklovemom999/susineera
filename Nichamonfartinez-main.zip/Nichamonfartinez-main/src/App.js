import logo from './logo.svg';
import './App.css';

function App() {
  window.location="https://www.one.siriworldlove.xyz/2023/09/23/ᴛʜᴇ-ʙᴇꜱᴛ-ɪꜱ-ʏᴇᴛ-ᴛᴏ-ᴄᴏᴍᴇ/";
  return (
    <div className="App">

    </div>
  );
}

export default App;
